let constant={
    stagingBaseurl:"https://main-nicely--unchanged--kangaroo-sbx-pgsdemo-com.sbx.preview.pagescdn.com/"
    
    
    }
    
    export default constant