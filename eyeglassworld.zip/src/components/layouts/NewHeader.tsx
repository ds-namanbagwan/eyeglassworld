import * as React from "react"


export default function NewHeader(props: any) {
    // console.log(props, "26812282428242s")

    return (
        <>
            <div className="w-80 ml-4"><img src={props?.prop?.c_photo?.url} /></div>
         
            <div className="bg-green text-2xl text-white">
                <div className="flex gap-24 ml-6" style={{paddingBottom:"10px"}}>
            {props?.prop?.c_headdata2?.map((res: any) => {
                            return (
                                <>
                                    <div className="mt-2">
                                        {res?.label}
                                    </div>

                                </>
                            )
                        })}
                        </div>
            </div>
            

        </>
    )
}
