export type nearByLocation = {    
    entities: object;
  
 };
  