import{s as t}from"../static/global-e7c991d2.js";const o={name:"robots"},e=()=>"robots.txt",s=r=>`Sitemap: ${t}/sitemap.xml
  User-agent: /`;export{o as config,e as getPath,s as render};
