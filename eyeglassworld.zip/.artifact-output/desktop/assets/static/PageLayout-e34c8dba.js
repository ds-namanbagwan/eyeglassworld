import{j as t,F as o}from"./jsx-runtime-fa9d47c9.js";const g=({title:l,_site:r,global:s,children:a})=>t(o,{children:a});export{g as P};
